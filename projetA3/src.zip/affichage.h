#include "define.h"


void affichage(oxy myOxy);
