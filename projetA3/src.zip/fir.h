#include "define.h"

absorp firTest(char* filename);
absorp fir(absorp myAbsorp, absorp *tab);
void buffer();