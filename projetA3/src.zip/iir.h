#include "define.h"

#define ALPHA (0.992)


absorp iirTest(char* filename);
absorp iir(absorp valeurSignal, param_iir*);
