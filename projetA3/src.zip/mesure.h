#include "define.h"

oxy mesureTest(char* filename);

	
