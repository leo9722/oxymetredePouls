#include "define.h"

oxy mesureTest(char* filename);
oxy mesure(absorp* myAbsorp, oxy myOxy, float* memoire, float *minMax, int* passage_zero, float* compteur_periodeCon);